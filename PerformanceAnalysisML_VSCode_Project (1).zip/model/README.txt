Place trained model artifacts here if you later switch from in-app training to saved models.
