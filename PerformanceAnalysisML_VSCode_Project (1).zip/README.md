# Performance Analysis Using Random Forest and XGBoost Feature Importance

A Flask + Python + HTML/CSS/JavaScript educational ML dashboard with user authentication.

## Features
- **User Authentication**: Secure Login & Registration system using SQLite (`data/users.db`) and salted password hashing (`werkzeug.security`).
- **Live Prediction Engine**: Predict performance scores with Random Forest and XGBoost.
- **Model Explainability**: Individual feature impact and global permutation feature importance.
- **Performance Evaluation**: Model metrics (MAE, RMSE, R², Accuracy) and actual vs. predicted comparison.
- **Project Overview**: Academic team details and documentation links.

## Pages
- **Login**: `/login` (existing users)
- **Register**: `/register` (new users)
- **Home**: `/` (dashboard)
- **Live Analytics & Prediction**: `/prediction`
- **Feature Importance & Insights**: `/feature-importance`
- **Model Performance & Evaluation**: `/performance`
- **Project & Team Information**: `/project`

## Run in VS Code

### 1. Open this folder
Open `PerformanceAnalysisML_VSCode_Project` in VS Code.

### 2. Create a virtual environment
macOS/Linux:
```bash
python3 -m venv .venv
source .venv/bin/activate
```

Windows:
```bash
python -m venv .venv
.venv\Scripts\activate
```

### 3. Install packages
```bash
pip install -r requirements.txt
```

### 4. Start the Application
```bash
python app.py
```

Open your browser at:
`http://127.0.0.1:5000`

If not logged in, you will be directed to the **Login** page. New users can click **Register here** to create an account and sign in.
