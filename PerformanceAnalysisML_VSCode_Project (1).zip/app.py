from flask import Flask, render_template, request, jsonify, send_from_directory, redirect, url_for, session, flash
import os, json, sqlite3, numpy as np, pandas as pd
from functools import wraps
from werkzeug.security import generate_password_hash, check_password_hash
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.inspection import permutation_importance

try:
    from xgboost import XGBRegressor
    XGB_AVAILABLE = True
except Exception:
    XGB_AVAILABLE = False

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "performance_analysis_ml_secret_key_2026")

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, "data", "users.db")

def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    with get_db() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                email TEXT UNIQUE NOT NULL,
                password_hash TEXT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        conn.commit()

init_db()

def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if "user_id" not in session:
            flash("Please log in to access this page.", "warning")
            return redirect(url_for("login", next=request.path))
        return f(*args, **kwargs)
    return decorated_function

FEATURES = ["speed", "passing", "stamina", "shooting", "dribbling",
            "tackling", "strength", "accuracy", "match_experience"]
TARGET = "performance_score"

def make_demo_data(n=700, seed=42):
    rng = np.random.default_rng(seed)
    X = rng.uniform(30, 100, size=(n, len(FEATURES)))
    # A deterministic educational target with noise.
    weights = np.array([0.13, 0.14, 0.12, 0.14, 0.10, 0.09, 0.08, 0.11, 0.09])
    y = np.clip(X @ weights + rng.normal(0, 3.0, n), 0, 100)
    return pd.DataFrame(X, columns=FEATURES).assign(**{TARGET: y})

df = make_demo_data()
X = df[FEATURES]
y = df[TARGET]
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.20, random_state=42)

rf = RandomForestRegressor(n_estimators=250, random_state=42, max_depth=10, n_jobs=-1)
rf.fit(X_train, y_train)

if XGB_AVAILABLE:
    xgb = XGBRegressor(n_estimators=250, max_depth=5, learning_rate=0.05,
                       subsample=0.9, colsample_bytree=0.9, random_state=42,
                       objective="reg:squarederror", n_jobs=2)
    xgb.fit(X_train, y_train)
else:
    xgb = None

def metrics(model):
    pred = model.predict(X_test)
    return {
        "mae": round(float(mean_absolute_error(y_test, pred)), 3),
        "rmse": round(float(np.sqrt(mean_squared_error(y_test, pred))), 3),
        "r2": round(float(r2_score(y_test, pred)), 3),
        "accuracy": round(float(max(0, 100 - np.mean(np.abs(y_test - pred)))), 2)
    }

def importance(model):
    result = permutation_importance(model, X_test, y_test, n_repeats=5, random_state=42, n_jobs=-1)
    vals = np.maximum(result.importances_mean, 0)
    total = vals.sum() or 1
    return [{"feature": f.replace("_", " ").title(), "importance": round(float(v/total*100), 2)}
            for f, v in sorted(zip(FEATURES, vals), key=lambda z: z[1], reverse=True)]

def model_for(name):
    if name == "xgboost" and xgb is not None:
        return xgb
    return rf

@app.route("/register", methods=["GET", "POST"])
def register():
    if "user_id" in session:
        return redirect(url_for("home"))
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        confirm_password = request.form.get("confirm_password", "")
        if not username or not email or not password:
            flash("All fields are required.", "danger")
            return render_template("register.html", username=username, email=email)
        if len(password) < 6:
            flash("Password must be at least 6 characters long.", "danger")
            return render_template("register.html", username=username, email=email)
        if password != confirm_password:
            flash("Passwords do not match.", "danger")
            return render_template("register.html", username=username, email=email)
        try:
            with get_db() as conn:
                hashed = generate_password_hash(password)
                conn.execute(
                    "INSERT INTO users (username, email, password_hash) VALUES (?, ?, ?)",
                    (username, email, hashed)
                )
                conn.commit()
            flash("Account registered successfully! Please sign in.", "success")
            return redirect(url_for("login"))
        except sqlite3.IntegrityError:
            flash("Username or email already exists. Please choose another.", "danger")
            return render_template("register.html", username=username, email=email)
    return render_template("register.html")

@app.route("/login", methods=["GET", "POST"])
def login():
    if "user_id" in session:
        return redirect(url_for("home"))
    if request.method == "POST":
        login_id = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        if not login_id or not password:
            flash("Please enter both username/email and password.", "danger")
            return render_template("login.html", username=login_id)
        with get_db() as conn:
            user = conn.execute(
                "SELECT * FROM users WHERE username = ? OR email = ?",
                (login_id, login_id.lower())
            ).fetchone()
        if user and check_password_hash(user["password_hash"], password):
            session.clear()
            session["user_id"] = user["id"]
            session["username"] = user["username"]
            session["email"] = user["email"]
            flash(f"Welcome back, {user['username']}!", "success")
            next_page = request.args.get("next")
            if next_page and next_page.startswith("/"):
                return redirect(next_page)
            return redirect(url_for("home"))
        else:
            flash("Invalid username/email or password.", "danger")
            return render_template("login.html", username=login_id)
    return render_template("login.html")

@app.route("/logout")
def logout():
    session.clear()
    flash("You have been signed out.", "info")
    return redirect(url_for("login"))

@app.route("/")
@login_required
def home():
    return render_template("index.html")

@app.route("/prediction")
@login_required
def prediction():
    return render_template("prediction.html")

@app.route("/feature-importance")
@login_required
def feature_page():
    return render_template("feature_importance.html")

@app.route("/performance")
@login_required
def performance():
    return render_template("performance.html")

@app.route("/project")
@login_required
def project():
    return render_template("project.html")

@app.route("/api/predict", methods=["POST"])
@login_required
def predict():
    data = request.get_json(force=True)
    model_name = data.get("model", "random_forest")
    model = model_for(model_name)
    row = []
    for f in FEATURES:
        try:
            row.append(float(data[f]))
        except (KeyError, TypeError, ValueError):
            return jsonify({"error": f"Invalid value for {f}"}), 400
    pred = float(np.clip(model.predict([row])[0], 0, 100))
    baseline = np.array([X_train[f].mean() for f in FEATURES])
    impacts = np.array(row) - baseline
    raw = impacts * np.array(getattr(model, "feature_importances_", np.ones(len(FEATURES))))
    scale = np.max(np.abs(raw)) or 1
    contributions = [{"feature": f.replace("_", " ").title(),
                      "impact": round(float(v/scale*100), 2)}
                     for f, v in zip(FEATURES, raw)]
    return jsonify({
        "prediction": round(pred, 2),
        "model": "XGBoost" if model_name == "xgboost" and xgb is not None else "Random Forest",
        "contributions": contributions
    })

@app.route("/api/summary")
@login_required
def summary():
    return jsonify({
        "models": {
            "random_forest": metrics(rf),
            "xgboost": metrics(xgb) if xgb is not None else None
        },
        "feature_importance": {
            "random_forest": importance(rf),
            "xgboost": importance(xgb) if xgb is not None else []
        },
        "actual": [round(float(v), 2) for v in y_test.iloc[:80]],
        "pred_rf": [round(float(v), 2) for v in rf.predict(X_test.iloc[:80])],
        "pred_xgb": [round(float(v), 2) for v in (xgb.predict(X_test.iloc[:80]) if xgb is not None else rf.predict(X_test.iloc[:80]))],
        "xgb_available": XGB_AVAILABLE
    })

@app.route("/download/<path:filename>")
@login_required
def download(filename):
    return send_from_directory(".", filename, as_attachment=True)

if __name__ == "__main__":
    app.run(debug=True, host="127.0.0.1", port=5000)
