Place your real player-performance CSV here. The current app uses a generated demo dataset in app.py.
