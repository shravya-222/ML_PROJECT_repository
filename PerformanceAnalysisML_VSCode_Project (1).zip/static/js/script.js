// Shared page JavaScript can be added here as the project grows.
