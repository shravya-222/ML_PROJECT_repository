const form = document.getElementById("predictionForm");
form.addEventListener("submit", async (e) => {
  e.preventDefault();
  const data = Object.fromEntries(new FormData(form).entries());
  ["speed","passing","stamina","shooting","dribbling","tackling","strength","accuracy","match_experience"]
    .forEach(k => data[k] = Number(data[k]));
  document.getElementById("message").textContent = "Calculating...";
  const res = await fetch("/api/predict", {method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(data)});
  const out = await res.json();
  if(out.error){document.getElementById("message").textContent=out.error;return;}
  document.getElementById("score").textContent = out.prediction.toFixed(2);
  document.getElementById("modelName").textContent = out.model;
  document.getElementById("message").textContent = "Prediction generated successfully.";
  const max = Math.max(...out.contributions.map(x=>Math.abs(x.impact)),1);
  document.getElementById("impactList").innerHTML = out.contributions
    .sort((a,b)=>Math.abs(b.impact)-Math.abs(a.impact))
    .map(x=>`<div class="impact-row"><div class="impact-top"><span>${x.feature}</span><span>${x.impact.toFixed(1)}%</span></div><div class="bar"><i style="width:${Math.min(Math.abs(x.impact)/max*100,100)}%"></i></div></div>`).join("");
});
