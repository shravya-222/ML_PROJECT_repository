async function loadPerformance(){
 const d=await (await fetch("/api/summary")).json();
 const models=[["Random Forest",d.models.random_forest],["XGBoost",d.models.xgboost]].filter(x=>x[1]);
 document.getElementById("metrics").innerHTML=models.flatMap(([name,m])=>[
  `<div class="metric"><small>${name} · MAE</small><strong>${m.mae}</strong></div>`,
  `<div class="metric"><small>${name} · RMSE</small><strong>${m.rmse}</strong></div>`,
  `<div class="metric"><small>${name} · R²</small><strong>${m.r2}</strong></div>`,
  `<div class="metric"><small>${name} · Error-based score</small><strong>${m.accuracy}%</strong></div>`
 ]).join("");
 const labels=d.actual.map((_,i)=>i+1);
 new Chart(document.getElementById("predictionChart"),{type:"line",data:{labels,datasets:[
  {label:"Actual",data:d.actual,borderWidth:2,tension:.2},
  {label:"Random Forest",data:d.pred_rf,borderWidth:2,tension:.2},
  {label:"XGBoost",data:d.pred_xgb,borderWidth:2,tension:.2}
 ]},options:{responsive:true,maintainAspectRatio:false,scales:{y:{beginAtZero:true,max:100}}}});
}
loadPerformance();
