async function loadInsights(){
 const d=await (await fetch("/api/summary")).json();
 const make=(id,items)=>new Chart(document.getElementById(id),{type:"bar",data:{labels:items.map(x=>x.feature),datasets:[{label:"Importance %",data:items.map(x=>x.importance),borderWidth:0}]},options:{responsive:true,maintainAspectRatio:false,indexAxis:"y",plugins:{legend:{display:false}},scales:{x:{beginAtZero:true}}}});
 make("rfChart",d.feature_importance.random_forest);
 make("xgbChart",d.feature_importance.xgboost);
 const rf=Object.fromEntries(d.feature_importance.random_forest.map(x=>[x.feature,x.importance]));
 const xg=Object.fromEntries(d.feature_importance.xgboost.map(x=>[x.feature,x.importance]));
 const features=[...new Set([...Object.keys(rf),...Object.keys(xg)])];
 document.getElementById("importanceTable").innerHTML=features.map(f=>`<tr><td>${f}</td><td>${(rf[f]??0).toFixed(2)}%</td><td>${(xg[f]??0).toFixed(2)}%</td></tr>`).join("");
}
loadInsights();
