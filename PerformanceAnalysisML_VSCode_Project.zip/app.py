from flask import Flask, render_template, request, jsonify, send_from_directory
import os, json, numpy as np, pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.inspection import permutation_importance

try:
    from xgboost import XGBRegressor
    XGB_AVAILABLE = True
except Exception:
    XGB_AVAILABLE = False

app = Flask(__name__)

FEATURES = ["speed", "passing", "stamina", "shooting", "dribbling",
            "tackling", "strength", "accuracy", "match_experience"]
TARGET = "performance_score"

def make_demo_data(n=700, seed=42):
    rng = np.random.default_rng(seed)
    X = rng.uniform(30, 100, size=(n, len(FEATURES)))
    # A deterministic educational target with noise.
    weights = np.array([0.13, 0.14, 0.12, 0.14, 0.10, 0.09, 0.08, 0.11, 0.09])
    y = np.clip(X @ weights + rng.normal(0, 3.0, n), 0, 100)
    return pd.DataFrame(X, columns=FEATURES).assign(**{TARGET: y})

df = make_demo_data()
X = df[FEATURES]
y = df[TARGET]
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.20, random_state=42)

rf = RandomForestRegressor(n_estimators=250, random_state=42, max_depth=10, n_jobs=-1)
rf.fit(X_train, y_train)

if XGB_AVAILABLE:
    xgb = XGBRegressor(n_estimators=250, max_depth=5, learning_rate=0.05,
                       subsample=0.9, colsample_bytree=0.9, random_state=42,
                       objective="reg:squarederror", n_jobs=2)
    xgb.fit(X_train, y_train)
else:
    xgb = None

def metrics(model):
    pred = model.predict(X_test)
    return {
        "mae": round(float(mean_absolute_error(y_test, pred)), 3),
        "rmse": round(float(np.sqrt(mean_squared_error(y_test, pred))), 3),
        "r2": round(float(r2_score(y_test, pred)), 3),
        "accuracy": round(float(max(0, 100 - np.mean(np.abs(y_test - pred)))), 2)
    }

def importance(model):
    result = permutation_importance(model, X_test, y_test, n_repeats=5, random_state=42, n_jobs=-1)
    vals = np.maximum(result.importances_mean, 0)
    total = vals.sum() or 1
    return [{"feature": f.replace("_", " ").title(), "importance": round(float(v/total*100), 2)}
            for f, v in sorted(zip(FEATURES, vals), key=lambda z: z[1], reverse=True)]

def model_for(name):
    if name == "xgboost" and xgb is not None:
        return xgb
    return rf

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/prediction")
def prediction():
    return render_template("prediction.html")

@app.route("/feature-importance")
def feature_page():
    return render_template("feature_importance.html")

@app.route("/performance")
def performance():
    return render_template("performance.html")

@app.route("/project")
def project():
    return render_template("project.html")

@app.route("/api/predict", methods=["POST"])
def predict():
    data = request.get_json(force=True)
    model_name = data.get("model", "random_forest")
    model = model_for(model_name)
    row = []
    for f in FEATURES:
        try:
            row.append(float(data[f]))
        except (KeyError, TypeError, ValueError):
            return jsonify({"error": f"Invalid value for {f}"}), 400
    pred = float(np.clip(model.predict([row])[0], 0, 100))
    baseline = np.array([X_train[f].mean() for f in FEATURES])
    impacts = np.array(row) - baseline
    raw = impacts * np.array(getattr(model, "feature_importances_", np.ones(len(FEATURES))))
    scale = np.max(np.abs(raw)) or 1
    contributions = [{"feature": f.replace("_", " ").title(),
                      "impact": round(float(v/scale*100), 2)}
                     for f, v in zip(FEATURES, raw)]
    return jsonify({
        "prediction": round(pred, 2),
        "model": "XGBoost" if model_name == "xgboost" and xgb is not None else "Random Forest",
        "contributions": contributions
    })

@app.route("/api/summary")
def summary():
    return jsonify({
        "models": {
            "random_forest": metrics(rf),
            "xgboost": metrics(xgb) if xgb is not None else None
        },
        "feature_importance": {
            "random_forest": importance(rf),
            "xgboost": importance(xgb) if xgb is not None else []
        },
        "actual": [round(float(v), 2) for v in y_test.iloc[:80]],
        "pred_rf": [round(float(v), 2) for v in rf.predict(X_test.iloc[:80])],
        "pred_xgb": [round(float(v), 2) for v in (xgb.predict(X_test.iloc[:80]) if xgb is not None else rf.predict(X_test.iloc[:80]))],
        "xgb_available": XGB_AVAILABLE
    })

@app.route("/download/<path:filename>")
def download(filename):
    return send_from_directory(".", filename, as_attachment=True)

if __name__ == "__main__":
    app.run(debug=True, host="127.0.0.1", port=5000)
