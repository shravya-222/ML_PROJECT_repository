# Performance Analysis Using Random Forest and XGBoost Feature Importance

A Flask + Python + HTML/CSS/JavaScript educational ML dashboard.

## Pages
- Home
- Live Analytics & Prediction
- Feature Importance & Insights
- Model Performance & Evaluation
- Project & Team Information

## Run in VS Code

### 1. Open this folder
Open `PerformanceAnalysisML` in VS Code.

### 2. Create a virtual environment
macOS/Linux:
```bash
python3 -m venv .venv
source .venv/bin/activate
```

Windows:
```bash
python -m venv .venv
.venv\Scripts\activate
```

### 3. Install packages
```bash
pip install -r requirements.txt
```

### 4. Start
```bash
python app.py
```

Open:
http://127.0.0.1:5000

The application creates an educational demo dataset when no external dataset is supplied. Replace `make_demo_data()` with your actual CSV/model pipeline for your final academic results.
